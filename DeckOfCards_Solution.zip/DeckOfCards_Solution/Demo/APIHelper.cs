﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace APICommonLib
{
	public class APIHelper<T>
	{ 
		public RestClient restClient;
		public RestRequest restRequest;
		public string baseURL = "https://deckofcardsapi.com/";

		public RestClient SetUrl(string endpoint)
		{
			var url = baseURL + endpoint;
			var restClient = new RestClient(url);
			return restClient;
		}

		public RestRequest CreateGetRequest()
		{
			var restRequest = new RestRequest(Method.GET);
			restRequest.AddHeader("Accept", "application/josn");
			restRequest.AddHeader("Referer", "https://deckofcardsapi.com/");
			return restRequest;
		}

		public RestRequest CreatePostRequest(string payload)			
		{			
			var restRequest = new RestRequest(Method.POST);
			restRequest.AddHeader("Accept", "application/json");
		    //Creating Json object
			JObject jObjectbody = new JObject();
			jObjectbody.Add("jokers_enabled", "true");
			//Adding Json body as parameter to the post request
			restRequest.AddParameter("application/json", jObjectbody, ParameterType.RequestBody);
         	restRequest.RequestFormat = DataFormat.Json;
			return restRequest;

		}

		public IRestResponse GetResponse(RestClient client, RestRequest request)
		{
			return client.Execute(request);
		}

		public DTO GetContent<DTO>(IRestResponse response)
		{
			var content = response.Content;
			DTO dtoObject = JsonConvert.DeserializeObject<DTO>(content);
			return dtoObject;
		}

	}

}
