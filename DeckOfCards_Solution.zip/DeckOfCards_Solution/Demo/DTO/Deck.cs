﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace APICommonLib
{
	public class Deck
    {

        [JsonProperty("success")]
        public bool Success { get; set; }

        [JsonProperty("deck_id")]
        public string DeckId { get; set; }

        [JsonProperty("remaining")]
        public long Remaining { get; set; }

        [JsonProperty("shuffled")]
        public bool Shuffled { get; set; }
        
        [JsonProperty("jokers_enabled")]
        public bool jokers_enabled { get; set; }
    }

}