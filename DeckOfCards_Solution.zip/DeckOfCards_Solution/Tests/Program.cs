﻿using System;

namespace Tests
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			string Str = "This is my first day";
			string[] ss = Str.Split(' ');
			for (int i = 0; i< ss.Length; i++)
			{
				Console.WriteLine(ss[i]);
			}
		}
	}
}
