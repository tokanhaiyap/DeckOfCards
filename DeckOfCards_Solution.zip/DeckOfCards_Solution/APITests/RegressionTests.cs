﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using APICommonLib;
using RestSharp;
//using APIHelper;
namespace APITests
{
	[TestClass]
	public class RegressionTests
	{
		[TestMethod]
		public void CreateDeckOfCards()
		{
			var apiHelper = new APIHelper<Deck>();
			var apiURL = apiHelper.SetUrl("api/deck/new");
			var getRequest = apiHelper.CreateGetRequest();
			var response = apiHelper.GetResponse(apiURL, getRequest);
			//Deserialize the  response string and convert into the object
			Deck content = apiHelper.GetContent<Deck>(response);
			//Verify the contents of response
			Assert.AreEqual(true, content.Success);
			Assert.AreEqual(52, content.Remaining);
			Assert.AreEqual(false, content.Shuffled);
			Assert.IsNotNull(content.DeckId);
		}

		[TestMethod]
		public void AddJokers()
		{
			string payload = @"{""jokers_enabled"":""true""}";
			var apiHelper = new APIHelper<Deck>();
			var apiURL = apiHelper.SetUrl("api/deck/new/shuffle");
			var postRequest = apiHelper.CreatePostRequest(payload);
			var response = apiHelper.GetResponse(apiURL, postRequest);
			//Deserialize the  response string and convert into the object
			Deck content = apiHelper.GetContent<Deck>(response);
			Assert.AreEqual(true, content.Success);
			//Verify that value of 'remaining' field is displayed as 52
			Assert.AreEqual(52, content.Remaining);
		}

		[TestMethod]
		public void VerifyJokersAddition()
		{
			var apiHelper = new APIHelper<Deck>();
			var apiURL = apiHelper.SetUrl("api/deck/new/shuffle/?jokers_enabled=true");
			var getRequest = apiHelper.CreateGetRequest();
			var response = apiHelper.GetResponse(apiURL, getRequest);
			//Deserialize the  response string and convert into the object
			Deck content = apiHelper.GetContent<Deck>(response);
			//Verify the contents of response
			Assert.AreEqual(true, content.Success);
			//Verify after adding jokers, 'remaining' is increased by 2
			Assert.AreEqual(54, content.Remaining);
			Assert.AreEqual(true, content.Shuffled);
			Assert.IsNotNull(content.DeckId);
		}

		[TestMethod]
		public void DrawSingleDeckCard()
		{
			var apiHelper = new APIHelper<Deck>();
			var apiURL = apiHelper.SetUrl("api/deck/new");
			var getRequest = apiHelper.CreateGetRequest();
			var response = apiHelper.GetResponse(apiURL, getRequest);
			//Deserialize the  response string and convert into the object
			Deck content = apiHelper.GetContent<Deck>(response);
			Assert.AreEqual(true, content.Success);
			//Verify that value of 'remaining' field is displayed as 52
			Assert.AreEqual(52, content.Remaining);

			string deckId = content.DeckId.ToString();
			var drawAPIhelper = new APIHelper<DrawDeckCard>();
			string drawEndpoint = "/api/deck/" + deckId + @"/draw";
			var drawAPIurl = drawAPIhelper.SetUrl(drawEndpoint);
			var drawRequest = drawAPIhelper.CreateGetRequest();
			var drawResponse = drawAPIhelper.GetResponse(drawAPIurl, drawRequest);

			//Deserialize the  response string and convert into the object
			DrawDeckCard drawContent = drawAPIhelper.GetContent<DrawDeckCard>(drawResponse);
			Assert.AreEqual(true, drawContent.Success);
			//Verify that after drawing a card the 'remaining' is reduced by 1
			Assert.AreEqual(51, drawContent.Remaining);
			//Verify other contents of the response
			Assert.AreEqual("SPADES", drawContent.Cards[0].Suit);
			Assert.AreEqual("AS", drawContent.Cards[0].Code);
		}

		[TestMethod]
		public void DrawMultipleDeckCards()
		{
			var apiHelper = new APIHelper<Deck>();
			var apiURL = apiHelper.SetUrl("api/deck/new");
			var getRequest = apiHelper.CreateGetRequest();
			var response = apiHelper.GetResponse(apiURL, getRequest);

			//Deserialize the  response string and convert into the object
			Deck content = apiHelper.GetContent<Deck>(response);
			Assert.AreEqual(true, content.Success);
			Assert.AreEqual(52, content.Remaining);

			string deckId = content.DeckId.ToString();
			var drawAPIhelper = new APIHelper<DrawDeckCard>();
			string drawEndpoint = "/api/deck/" + deckId + @"/draw/?count=2";
			//Assert.AreEqual(false, content.Shuffled);
			var drawAPIurl = drawAPIhelper.SetUrl(drawEndpoint);
			var drawRequest = drawAPIhelper.CreateGetRequest();
			var drawResponse = drawAPIhelper.GetResponse(drawAPIurl, drawRequest);

			//Desrialize the  response string and convert into the object
			DrawDeckCard drawContent = drawAPIhelper.GetContent<DrawDeckCard>(drawResponse);
			Assert.AreEqual(true, drawContent.Success);
			int expectedRemaining = 52 - 2;
			//Verify that after drawing 2 cards, the 'remaining' is decreased by 2
			Assert.AreEqual(expectedRemaining, drawContent.Remaining);
			Assert.AreEqual("SPADES", drawContent.Cards[0].Suit);
			Assert.AreEqual("AS", drawContent.Cards[0].Code);
		}

	}
}
