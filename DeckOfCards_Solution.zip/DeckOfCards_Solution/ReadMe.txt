Copy the folder to some location on a local machine
Open the Solution 'TestAutomation.sln' from DeckOfCards_Solution folder
Right click on TestAutomation solution and select 'Rebuild Solution'
Select Test->Test Explorer from the Test menu
Right click on 'DeckOfCards_NUnit' test project and run the NUnit test suite by selecting run menu item
Or Right click on' DeckOfCards_MSTest' test projct and run the 'MSTest' test suite by selecting run menu item 
APIHelper.cs under APIAutomation project has all the reusable methods
RestSharp and Newtonsoft libraries are used for the framework development
Acronym used: DTO- Data Transformation Object
ReadMe\FolderStructure.png represents the folder strucure and the test results